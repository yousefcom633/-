// Generates web icons (public/icons/*.png) and the source images @capacitor/assets needs (assets/*).
import sharp from "sharp";
import fs from "fs";

fs.mkdirSync("assets", { recursive: true });
fs.mkdirSync("public/icons", { recursive: true });
const svg = fs.readFileSync("public/icons/icon.svg", "utf8");

const bgRects = /<rect width="1024" height="1024" fill="url\(#bg\)"\/><rect width="1024" height="1024" fill="url\(#glow\)"\/>/;
const fgSvg = svg.replace(bgRects, "").replace("scale(0.92)", "scale(0.6)");
const bgSvg = svg.replace(/<g transform="translate\(512 512\) scale\(0\.92\)[\s\S]*<\/g>\s*<\/svg>/, "</svg>");
const buf = (s) => Buffer.from(s);
const png = (input, size, file) => sharp(input).resize(size, size).png().toFile(file);
const round = (size) => buf(`<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}"><rect width="${size}" height="${size}" rx="${Math.round(size * 0.23)}"/></svg>`);
const rounded = async (size) => sharp(buf(svg)).resize(size, size).composite([{ input: round(size), blend: "dest-in" }]).png().toBuffer();

// web / PWA icons
for (const s of [192, 512, 1024]) fs.writeFileSync(`public/icons/icon-${s}.png`, await rounded(s));
await png(buf(svg), 512, "public/icons/maskable-512.png");
fs.writeFileSync("public/icons/apple-touch-icon.png", await sharp(buf(svg)).resize(180, 180).png().toBuffer());

// Android launcher sources
await png(buf(svg), 1024, "assets/icon-only.png");
await png(buf(fgSvg), 1024, "assets/icon-foreground.png");
await png(buf(bgSvg), 1024, "assets/icon-background.png");

// splash
const logo = await rounded(720);
for (const [file, color] of [["splash.png", "#F5F6FA"], ["splash-dark.png", "#0E0F14"]]) {
  await sharp({ create: { width: 2732, height: 2732, channels: 4, background: color } })
    .composite([{ input: logo, gravity: "center" }])
    .png()
    .toFile(`assets/${file}`);
}
console.log("assets done");
