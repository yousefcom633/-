import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.dryousef.tasks.classic",
  appName: "مهمات Dr.Yousef (Classic)",
  webDir: "out",
  android: { backgroundColor: "#F5F6FA" },
};

export default config;
