// Thin bridge to Capacitor native plugins. On the web everything here is a no-op.
import { Capacitor } from "@capacitor/core";
import { Directory, Encoding, Filesystem } from "@capacitor/filesystem";
import { LocalNotifications } from "@capacitor/local-notifications";
import { Share } from "@capacitor/share";

export const isNative = typeof window !== "undefined" && Capacitor.isNativePlatform();

/** Save text to the app cache and open the Android share sheet (Drive, Files, WhatsApp...). Used for JSON backups. */
export async function shareFile(name: string, text: string) {
  try {
    const r = await Filesystem.writeFile({ path: name, data: text, directory: Directory.Cache, encoding: Encoding.UTF8 });
    await Share.share({ title: name, dialogTitle: name, url: r.uri });
  } catch {
    /* user closed the share sheet */
  }
}

const CHANNEL = "tasks";
let perm: NotificationPermission = "default";
const map = (d: string): NotificationPermission => (d === "granted" ? "granted" : d === "denied" ? "denied" : "default");

if (isNative) {
  LocalNotifications.checkPermissions()
    .then((r) => {
      perm = map(r.display);
    })
    .catch(() => {});
  LocalNotifications.createChannel({ id: CHANNEL, name: "Tasks", importance: 4, vibration: true }).catch(() => {});
}

export const nativePermission = () => perm;

export async function nativeAskPermission() {
  try {
    const r = await LocalNotifications.requestPermissions();
    perm = map(r.display);
  } catch {
    perm = "denied";
  }
  return perm;
}

let seq = 0;
export function nativeNotify(title: string, body: string) {
  const id = ((Date.now() % 2000000000) + seq++) % 2147000000;
  LocalNotifications.schedule({
    notifications: [{ id, title, body, channelId: CHANNEL, schedule: { at: new Date(Date.now() + 300) } }],
  }).catch(() => {});
}
