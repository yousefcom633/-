# النسخة Classic (Next.js) → APK بدون نت
ارفعها في مستودع GitHub منفصل: ارفع `project-2.zip` من غير فك، ثم أنشئ `.github/workflows/build-apk.yml` والصق كود الـ workflow، وبعد البناء نزّل الـ APK من Releases.
معرّف التطبيق `com.dryousef.tasks.classic` مختلف عن النسخة الأولى، فيتثبتوا الاتنين جنب بعض.
