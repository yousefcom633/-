import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export", // static site → copied into the Android app (works fully offline)
  trailingSlash: true,
  images: { unoptimized: true },
};

export default nextConfig;
